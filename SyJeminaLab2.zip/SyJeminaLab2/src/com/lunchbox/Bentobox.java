package com.lunchbox;

public class Bentobox extends Lunchbox {
	public Bentobox() {
		System.out.println("New Bento Box");
	}
}
