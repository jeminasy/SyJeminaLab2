package com.lunchbox;

public class Lunchbox {
	private double length;
	private double width;
	private double height;
	private double volume;
	String color = "blue";
	int colors = 6;
	
	public Lunchbox() {
		System.out.println("New Lunchbox");
	}
	public Lunchbox(double length, double width, double height, double volume) {
		this.length = length;
		this.width = width;
		this.height = height;
		this.volume = volume;
	}
	public void setDimensions(double l, double w, double h, double v) {
		this.length = l;
		this.width = w;
		this.height = h;
		this.volume = v;
	}
	public double getLength() {
		return this.length;
	}
	public double getWidth() {
		return this.width;
	}
	public double getHeight() {
		return this.height;
	}
	public double getVolume() {
		return this.volume;
	}
	public void color() {
		System.out.println("This lunchbox is colored " + color);
	}
	public void colors() {
		System.out.println("This lunchbox has " + colors + " different colors");
	}
	 
}