package com.lunchbox;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lunchbox parent = new Lunchbox(17.2, 23, 7.2, 1800);
		System.out.println("Length is " + parent.getLength());
		System.out.println("Width is " + parent.getWidth());
		System.out.println("Height is " + parent.getHeight());
		System.out.println("Volume is " + parent.getVolume());
		parent.color();
		parent.colors();
		
		System.out.println();
		Bentobox child = new Bentobox();
		child.setDimensions(15, 20, 5, 1500);
		System.out.println("Length is "+ child.getLength());
		System.out.println("Width is " + child.getWidth());
		System.out.println("Height is " + child.getHeight());
		System.out.println("Volume is " + child.getVolume());
		child.color();
		child.colors();
		
//		//polymorphism?
//		Lunchbox container[]=new Lunchbox[2];
//		container[0] = new Lunchbox();
//		container[1] = new Bentobox();
//		for (int x=0; x>2; ++x) {
//			container[x].color("green");
//			container[x].colors(6);
//		}
	}

}
